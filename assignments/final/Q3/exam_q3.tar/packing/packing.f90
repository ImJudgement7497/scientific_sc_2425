module constants
    integer, parameter :: dp = selected_real_kind(15,307)
end module constants

module mt19937
    !************************************************************************************************
    !*
    !*                                       Module mt19937
    !*
    !*                   Module using the Mersenne Twister Random Number Generator
    !*
    !************************************************************************************************
    !use global_parameters
    implicit none
    ! Period parameters
    integer, parameter :: n = 624, n1 = n+1, m = 397, mata = -1727483681
    !                                    constant vector a
    integer, parameter :: umask = -2147483647 - 1
    !                                    most significant w-r bits
    integer, parameter :: lmask =  2147483647
    !                                    least significant r bits
    ! Tempering parameters
    integer, parameter :: tmaskb= -1658038656, tmaskc= -272236544

    !                     the array for the state vector
    integer, save      :: mt(0:n-1), mti = n1
    !                     mti==N+1 means mt[N] is not initialized

    private
    public ::grnd, init_genrand,gaussian !sgrnd

    contains

    subroutine init_genrand(seed)
      ! This initialization is based upon the multiplier given on p.106 of the
      ! 3rd edition of Knuth, The Art of Computer Programming Vol. 2.
      ! This version assumes that integer overflow does NOT cause a crash.

      integer, intent(IN)  :: seed

      integer  :: latest

      mt(0) = seed
      latest = seed
      do mti = 1, n-1
         latest = ieor( latest, ishft( latest, -30 ) )
         latest = latest * 1812433253 + mti
         mt(mti) = latest
      end do

      return
    end subroutine init_genrand

    !***********************************************************************

    function grnd() result(fn_val)
        use constants
        real(kind=dp) :: fn_val

        integer, save :: mag01(0:1) = (/ 0, mata /)
        !                        mag01(x) = x * MATA for x=0,1
        integer       :: kk, y

        if(mti >= n) then
             !                       generate N words at one time
            if(mti == n+1) then
                !                            if init_genrnd() has not been called,
                call init_genrand(4357)
                !                              a default initial seed is used
            end if

            do  kk = 0, n-m-1
            y = ior(iand(mt(kk),umask), iand(mt(kk+1),lmask))
            mt(kk) = ieor(ieor(mt(kk+m), ishft(y,-1)),mag01(iand(y,1)))
            end do

            do  kk = n-m, n-2
                y = ior(iand(mt(kk),umask), iand(mt(kk+1),lmask))
                mt(kk) = ieor(ieor(mt(kk+(m-n)), ishft(y,-1)),mag01(iand(y,1)))
            end do

            y = ior(iand(mt(n-1),umask), iand(mt(0),lmask))
            mt(n-1) = ieor(ieor(mt(m-1), ishft(y,-1)),mag01(iand(y,1)))
            mti = 0

        end if

        y = mt(mti)
        mti = mti + 1
        y = ieor(y, tshftu(y))
        y = ieor(y, iand(tshfts(y),tmaskb))
        y = ieor(y, iand(tshftt(y),tmaskc))
        y = ieor(y, tshftl(y))

        if(y < 0) then
            fn_val = (dble(y) + 2.0_dp**32) / (2.0_dp**32 - 1.0_dp)
        else
            fn_val = dble(y) / (2.0_dp**32 - 1.0_dp)
        end if

        return
    end function grnd

    function gaussian() result(number)
    !================================================================================================
    !                              User Function gaussian
    !                      Outputs a gaussian random number
    !================================================================================================
    ! use mt19937
    use constants
    implicit none
    ! save

    real(kind=dp) :: number,x1,x2,w
    real(kind=dp), save :: y2
    integer,save :: logic

    if(logic == 0)then
    do
      x1 = 2.0_dp * grnd() - 1.0_dp
      x2 = 2.0_dp * grnd() - 1.0_dp

      w = x1*x1 + x2*x2

      if(w<1.0_dp) exit
    end do

    w=sqrt((-2.0_dp *log(w))/w)

    number = x1*w
    y2 = x2*w

    logic = 1
    else
    number = y2
    logic = 0
    end if

    return

    end function gaussian
    !******************************************

    function tshftu(y) result(fn_val)
      integer, intent(IN) :: y
      integer             :: fn_val

      fn_val = ishft(y,-11)
      return
    end function tshftu

    !******************************************

    function tshfts(y) result(fn_val)
      integer, intent(IN) :: y
      integer             :: fn_val

      fn_val = ishft(y,7)
      return
    end function tshfts

    !******************************************

    function tshftt(y) result(fn_val)
      integer, intent(IN) :: y
      integer             :: fn_val

      fn_val = ishft(y,15)
      return
    end function tshftt

    !******************************************

    function tshftl(y) result(fn_val)
      integer, intent(IN) :: y
      integer             :: fn_val

      fn_val = ishft(y,-18)
      return
    end function tshftl

end module mt19937

subroutine pbc_loop(x, y, z, particle_radius, fx, fy, fz, offset_x, &
&                   offset_y, offset_z, force_size, rix, riy, riz, rir, num_particles)
    use constants
    implicit none
    integer, intent(in) :: num_particles
    real(kind=dp), intent(in) :: x(num_particles), y(num_particles), z(num_particles)
    real(kind=dp), intent(in) :: particle_radius(num_particles)
    real(kind=dp), intent(out) :: fx, fy, fz
    real(kind=dp), intent(in) :: offset_x, offset_y, offset_z
    real(kind=dp), intent(in) :: force_size, rix, riy, riz, rir
    real(kind=dp) :: rjx, rjy, rjz, rjr
    real(kind=dp) :: dx, dy, dz, rr
    integer :: j

    ! Initialize forces
    fx = 0.0_dp
    fy = 0.0_dp
    fz = 0.0_dp

    do j = 1, num_particles
        rjx = x(j) + offset_x
        rjy = y(j) + offset_y
        rjz = z(j) + offset_z
        rjr = particle_radius(j)
        dx = rjx - rix
        dy = rjy - riy
        dz = rjz - riz
        rr = (rir + rjr) * (rir + rjr)

        ! Check if particles overlap
        if (dx*dx + dy*dy + dz*dz < rr) then
            fx = fx - force_size * dx
            fy = fy - force_size * dy
            fz = fz - force_size * dz
        end if
    end do

end subroutine pbc_loop

subroutine calculate_forces(x, y, z, particle_radius, force_x, force_y, &
&                           force_z, Lx, Ly, Lz, num_particles)
    use constants
    implicit none
    integer, intent(in) :: num_particles
    real(kind=dp), intent(in) :: x(num_particles), y(num_particles), z(num_particles)
    real(kind=dp), intent(in) :: particle_radius(num_particles)
    real(kind=dp), intent(out) :: force_x(num_particles)
    real(kind=dp), intent(out) :: force_y(num_particles)
    real(kind=dp), intent(out) :: force_z(num_particles)
    real(kind=dp), intent(in) :: Lx, Ly, Lz
    real(kind=dp) :: force_size, rix, riy, riz, rir
    real(kind=dp) :: fx, fy, fz
    logical :: bpx, bmx, bpy, bmy, bpz, bmz
    integer :: i
    real(kind=dp), parameter :: zero = 0.0_dp

    force_size = 0.1_dp

    ! Loop over all particles and calculate total force
    do i = 1, num_particles
        rix = x(i)
        riy = y(i)
        riz = z(i)
        rir = particle_radius(i)
        fx = 0.0_dp
        fy = 0.0_dp
        fz = 0.0_dp

        ! Internal interactions
        call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, zero, zero, &
        &             force_size, rix, riy, riz, rir, num_particles)

        bpx = rix > Lx - 1.1_dp * rir
        bmx = rix < 1.1_dp * rir
        bpy = riy > Ly - 1.1_dp * rir
        bmy = riy < 1.1_dp * rir
        bpz = riz > Lz - 1.1_dp * rir
        bmz = riz < 1.1_dp * rir

        ! Check for boundary forces in the plane
        if (bmx) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, zero, zero, &
        &                      force_size, rix, riy, riz, rir, num_particles)

        if (bpx) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, zero, zero, &
        &                      force_size, rix, riy, riz, rir, num_particles)

        if (bpy) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, Ly, zero, &
        &                      force_size, rix, riy, riz, rir, num_particles)

        if (bmy) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, -Ly, zero, &
        &                      force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bpy) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, Ly, zero, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bmy) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, -Ly, zero, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bpy) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, Ly, zero, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bmy) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, -Ly, zero, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        ! Check for boundary forces in the up direction
        if (bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, zero, Lz, &
        &                      force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, zero, Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, zero, Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bpy .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, Ly, Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bmy .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, -Ly, Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bpy .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, Ly, Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bmy .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, -Ly, Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bpy .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, Ly, Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bmy .and. bpz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, -Ly, Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        ! Check for boundary forces in the downward direction
        if (bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, zero, -Lz, &
        &                      force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, zero, -Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, zero, -Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bpy .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, Ly, -Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bmy .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, zero, -Ly, -Lz, &
        &                                force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bpy .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, Ly, -Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        if (bpx .and. bmy .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, Lx, -Ly, -Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bpy .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, Ly, -Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        if (bmx .and. bmy .and. bmz) call pbc_loop(x, y, z, particle_radius, fx, fy, fz, -Lx, -Ly, -Lz, &
        &                                          force_size, rix, riy, riz, rir, num_particles)

        force_x(i) = fx
        force_y(i) = fy
        force_z(i) = fz

    end do  ! End of i-loop

end subroutine calculate_forces

subroutine move_particles(x, y, z, fx, fy, fz, dt, num_particles)
    use constants
    implicit none
    integer, intent(in) :: num_particles
    real(kind=dp), intent(inout) :: x(num_particles), y(num_particles), z(num_particles)
    real(kind=dp), intent(in) :: fx(num_particles), fy(num_particles), fz(num_particles)
    real(kind=dp), intent(in) :: dt
    real(kind=dp) :: mass
    integer :: i

    mass = 1.0_dp

    ! Relaxation algorithm - move particles along the direction of force
    do i = 1, num_particles
        x(i) = x(i) + fx(i) * dt
        y(i) = y(i) + fy(i) * dt
        z(i) = z(i) + fz(i) * dt
    end do

end subroutine move_particles

subroutine shrink(x, y, z, L, dL, num_particles)
    use constants
    implicit none
    integer, intent(in) :: num_particles
    real(kind=dp), intent(inout) :: x(num_particles), y(num_particles), z(num_particles)
    real(kind=dp), intent(inout) :: L
    real(kind=dp), intent(in) :: dL
    real(kind=dp) :: shrink_factor
    integer :: i

    shrink_factor = (L - dL) / L

    ! Scale particle positions
    do i = 1, num_particles
        x(i) = x(i) * shrink_factor
        y(i) = y(i) * shrink_factor
        z(i) = z(i) * shrink_factor
    end do

    ! Change box size
    L = L - dL

end subroutine shrink

program particle_simulation
    use constants
    use mt19937
    implicit none
    integer, parameter :: num_particles = 4000
    integer :: i, j, t
    integer :: num_steps
    real(kind=dp) :: L, L_init, L_final, dL, dt
    real(kind=dp) :: mean_volume, mean_radius, volume_distribution
    real(kind=dp) :: x(num_particles), y(num_particles), z(num_particles)
    real(kind=dp) :: particle_volume(num_particles), particle_radius(num_particles)
    real(kind=dp) :: fx(num_particles), fy(num_particles), fz(num_particles)
    real(kind=dp) :: volume_bins(200), radius_bins(200)
    real(kind=dp) :: vol_spheres = 0.0;
    real(kind=dp), parameter :: ftpi = acos(-1.0_dp)*4.0_dp/3.0_dp

    ! Constants
    mean_volume = 200.0_dp
    mean_radius = (mean_volume / ftpi) ** (1.0_dp / 3.0_dp)
    volume_distribution = 0.3_dp

    ! print mean radius to file
    print *, "Mean radius: ", mean_radius

    ! Initialize random number generator
    call init_genrand(37322822)

    ! Generate lognormal distribution of particle volumes
    do i = 1, num_particles
        particle_volume(i) = mean_volume*(1.0+0.3*gaussian())
        particle_radius(i) = (particle_volume(i) / ftpi) ** (1.0_dp / 3.0_dp)
    end do

    ! Initialize bins
    volume_bins = 0.0_dp
    radius_bins = 0.0_dp

    ! Calculate volume distribution
    do i = 1, num_particles
        if (particle_volume(i) > 0.0_dp) then
            volume_bins(int((particle_volume(i) + 0.5_dp) / 10.0_dp) + 1) = &
&               volume_bins(int((particle_volume(i) + 0.5_dp) / 10.0_dp) + 1) + 1.0_dp
        end if
        if (particle_radius(i) > 0.0_dp) then
            radius_bins(int((particle_radius(i) + 0.5_dp) / 1.0_dp) + 1) = &
&               radius_bins(int((particle_radius(i) + 0.5_dp) / 1.0_dp) + 1) + 1.0_dp
        end if
    end do

    ! Write to file
    open(unit=10, file='volumes.txt')
    do i = 1, 200
        write(10, *) (i - 1) * 10.0_dp, volume_bins(i), (i - 1) * 1.0_dp, radius_bins(i)
    end do
    close(10)

    ! Box size
    L = 2.0_dp * (num_particles ** (1.0_dp / 3.0_dp)) * mean_radius
    L_init = 2.0_dp * L
    print *, 'System size: ', L

    ! Generate random positions of particles
    do i = 1, num_particles
        x(i) = L_init * grnd()
        y(i) = L_init * grnd()
        z(i) = L_init * grnd()
    end do

    ! Relax particles
    num_steps = 2000
    L_final = L
    dL = (L_init - L_final) / num_steps
    dt = 0.1_dp * mean_radius

    L = L_init
    do t = 1, num_steps
        call calculate_forces(x, y, z, particle_radius, fx, fy, fz, L, L, L, num_particles)
        call move_particles(x, y, z, fx, fy, fz, dt, num_particles)
        call shrink(x, y, z, L, dL, num_particles)
    end do

    ! Fine relaxation
    dt = 0.05_dp * mean_radius
    do t = 1, num_steps
        call calculate_forces(x, y, z, particle_radius, fx, fy, fz, L, L, L, num_particles)
        call move_particles(x, y, z, fx, fy, fz, dt, num_particles)
    end do

    ! Output final positions
    open(unit=11, file='final_positions.txt')
    do i = 1, num_particles
        write(11, *) x(i), y(i), z(i), particle_radius(i), fx(i), fy(i), fz(i)
    end do
    close(11)

    do i = 1, num_particles
         vol_spheres = vol_spheres + particle_volume(i)
    end do

    print *, "Final box size: ", L
    print *, "Box size change: ", dL
    print *, "Final density: ", vol_spheres / (L*L*L)

end program particle_simulation
